﻿ỦNG HỘ CHANNEL BỌN MÌNH NHA: https://www.youtube.com/channel/UC_XDuWauZCYEbzkpc8XRFeA


1. Chỗ này để lưu trữ các plugin update của kb2abot
2. kb2abot sẽ check version trên mạng với version trong máy, nếu conflict sẽ tải về
3. Nhớ là link của manifest.update.plugin và manifest.update.manifest đều là tải trực tiếp

ỦNG HỘ CHANNEL BỌN MÌNH NHA: https://www.youtube.com/channel/UC_XDuWauZCYEbzkpc8XRFeA