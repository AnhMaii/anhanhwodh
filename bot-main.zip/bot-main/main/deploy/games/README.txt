﻿ỦNG HỘ CHANNEL BỌN MÌNH NHA: https://www.youtube.com/channel/UC_XDuWauZCYEbzkpc8XRFeA

Chỗ này để lưu trữ các game của kb2abot

ỦNG HỘ CHANNEL BỌN MÌNH NHA: https://www.youtube.com/channel/UC_XDuWauZCYEbzkpc8XRFeA