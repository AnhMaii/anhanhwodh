﻿ỦNG HỘ CHANNEL BỌN MÌNH NHA: https://www.youtube.com/channel/UC_XDuWauZCYEbzkpc8XRFeA


1. Chỗ này để lưu trữ các plugin của kb2abot
2. Bọn mình có 1 folder trên drive để lưu trữ các plugin/game của kb2abot lại tại đây: https://drive.google.com/drive/folders/1hmi8F0JIv0MGVAnfcS5XAhhTalYcdTpW?usp=sharing
3. Các bạn ai có plugin muốn share thì liên hệ fb.com/khoakomlem để up lên nhé!
4. Nếu các bạn là người tải plugin thì hãy đặt các file dạng .zip tại đây và khởi động bot, bot sẽ tự động giải nén cho bạn.

ỦNG HỘ CHANNEL BỌN MÌNH NHA: https://www.youtube.com/channel/UC_XDuWauZCYEbzkpc8XRFeA