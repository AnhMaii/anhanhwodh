# Author : Khoa Ko Mlem
# Copyright (c) khoakomlem
# Script chạy bot
echo "Dang chay kb2abot bootloader . . ."
npm start
read -p "Nhan phim ENTER de thoat . . ."
