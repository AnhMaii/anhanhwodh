echo "Dang cai dat node_modules"
npm install
echo "Da xong!"
